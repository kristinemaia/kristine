# E-book v2 — replacement texts (paste into Canva)

_14 October 2026. Page numbers refer to "Ebook - Final.pdf" (39 pages). Keep your design; replace only the text blocks below. Nutrition figures marked ≈ are approximate and should be checked against the database you used for the book._

---

## Page 3 — Introduction (replace the second paragraph)

**Old:** "As someone passionate about health and wellness, I understand the challenges…"

**New:**
> I'm a sports science graduate and a certified recovery massage therapist, and I've spent the last five years streaming for hours a day, so I know exactly what long sessions at a desk do to a body and to an appetite. This book is the food side of how I stay healthy while sitting a lot: simple portions you can measure with your hands, foods that fill you up without weighing you down, and quick meals that fit around a long day. Nothing here is medical advice; it's what works for me, explained so it can work for you.

Add at the bottom of the page, small: *Not medical advice. If you have a medical condition, are pregnant or breastfeeding, or take medication, talk to your doctor before changing how you eat.*

---

## Page 5 — replace the whole page (header and text)

**Header:** MEASURING FOOD WITH YOUR HANDS

**Text:**
> You don't need a scale to eat well. Your hands are always with you, they scale with your body size, and they're accurate enough for everyday meals. That's why I use them for every plate, at home, at a restaurant or at my desk between streams.
>
> Portion control matters because the same healthy food, eaten in the wrong amount, still adds up. Hand portions keep meals balanced without counting anything, and they work for any way of eating: vegetarian, pescetarian, omnivore, low-carb.
>
> **Protein:** one palm (the size and thickness of your palm, no fingers) ≈ 100–120 g of fish, tofu, chicken or eggs.
> **Carbs:** one cupped hand ≈ one serving of rice, pasta, oats, potatoes or bread.
> **Vegetables:** one fist ≈ one serving of greens, broccoli, carrots, peppers.
> **Fats:** one thumb ≈ one serving of oil, butter, nuts, cheese or avocado.
>
> A simple plate for most people: one palm of protein, one fist of vegetables, one cupped hand of carbs, one thumb of fat. Hungrier day or training day: add a second palm or a second cupped hand. Lighter day: drop the carbs to half a hand. The chart on the next page shows which foods go in each hand.

---

## Page 6 — check the food names in Canva

The exported text reads "Solmon, Beons, Posto, Peos, Kole, Chickpeos". If the design file says Salmon, Beans, Pasta, Peas, Kale, Chickpeas, it's only the display font; if not, correct them.

---

## Page 8 — replace the whole page (header and text)

**Header:** LOW-CALORIE FOODS: SWAP, DON'T STARVE

**Text:**
> Low-calorie foods are the easiest way to eat more and weigh less: they fill the plate and the stomach without filling the day's calorie budget. I don't use them to eat tiny meals; I use them to make normal-sized meals lighter.
>
> On the next pages you'll find the foods I actually buy, with calories and protein per portion, so you can compare at a glance: milks and breads, fish and meat, eggs, dairy, plant proteins, fruit.
>
> How to use them:
> • **Add volume first.** Fruit and non-starchy vegetables (berries, apples, oranges, spinach, broccoli, peppers) make a meal bigger for almost nothing.
> • **Pick the protein that fills you.** White fish, tofu, eggs, Greek yogurt and cottage cheese keep you full for hours and protect muscle.
> • **Swap, don't remove.** Rye bread for white, skim or almond milk for full cream, air-popped popcorn or vegetable sticks with hummus instead of chips. Same meal, fewer calories.
> • **Use the charts when you shop.** Decide in the aisle, not at the table.

---

## Page 11 — fix one line

"Feta · 207 CARBS · 21.2g PROTEIN" → check your source. Feta is roughly ≈ 260 kcal, ≈ 14 g protein and ≈ 4 g carbs per 100 g; the 207 is almost certainly kcal, not carbs.

## Page 12 — fix one word

"Valnuts" → "Walnuts".

## Page 13 — fix units

"34g kCal", "41g kCal", etc. → "34 kcal", "41 kcal" (remove the "g").

## Page 14 — optional

The alcohol chart is off-brand for a book about eating well around long sessions. Keep it only if you want the comparison; otherwise replace the page with the shopping list (below).

---

## Page 15 — replace the whole page (header and text)

**Header:** INTERMITTENT FASTING (fix the spelling: "INTERMITTENT")

**Text:**
> Intermittent fasting means you eat within a window and don't eat outside it. It isn't a diet; it's a schedule. I like it on stream days because it removes decisions: I know when I eat and when I don't.
>
> **Why people use it:** fewer eating decisions, easier calorie control, and for many people steadier energy. Research also points to effects on insulin sensitivity and cell repair, but the honest summary is that most of the benefit comes from eating less without feeling deprived.
>
> **The three common ways:**
> • **16/8:** fast 16 hours, eat within 8 (for example 12:00–20:00). The easiest to keep.
> • **5:2:** eat normally five days a week, keep two non-consecutive days very light (500–600 kcal).
> • **Alternate days:** one normal day, one very light day. The hardest to sustain; I don't recommend it as a start.
>
> **What's fine during the fast:** water, sparkling water, plain tea, black coffee, herbal tea. **What breaks it:** anything with calories, including milk in coffee, juice, sweetened drinks and most "zero" drinks with flavourings that make you hungry.
>
> **How to make it work:** start with 12 hours and add an hour every few days; keep busy in the fasting hours (a stretch break helps more than a snack); drink more water than you think; if you feel dizzy, shaky or can't focus, eat and shorten the window; tell a friend or your community what you're doing, it's easier with company.
>
> *Not medical advice. Don't fast if you are pregnant or breastfeeding, under 18, have or had an eating disorder, have diabetes or take medication that depends on meals, unless your doctor agrees.*

---

## Page 24 or 25 — replace the duplicate "White fish with rice and veggies"

Keep page 24. Replace page 25 with:

**TUNA AND WHITE BEAN BOWL (no cooking, 10 minutes)**

Ingredients: 1 can tuna in water (≈ 120 g drained) · 150 g canned white beans, rinsed · 1 handful cherry tomatoes, halved · ½ cucumber, diced · ¼ red onion, thinly sliced · 1 tbsp olive oil · juice of ½ lemon · salt, pepper, dried oregano · a handful of rocket or spinach.

Nutritional information (per serving): Calories ≈ 420 kcal | Protein ≈ 38 g | Fat ≈ 16 g | Carbohydrates ≈ 30 g · Preparation time ≈ 10 minutes

Description: This is my desk lunch on long stream days: no pan, no oven, nothing to wash but a bowl. Drain the tuna and rinse the beans. Put everything in a bowl, add the oil, lemon, salt, pepper and oregano, and mix. If you have five more minutes, let it sit so the onion softens. Swap the tuna for 150 g of cubed baked tofu for a plant version. Eat it as it is or stuffed into a wholemeal pita.

---

## Page 33 — fix the title

"TOFU WITH MIXED GREEN SALAD" → **SALMON WITH GARLIC BROCCOLI**

---

## New page — THE SHOPPING LIST (one page, replaces the alcohol page or goes before the recipes)

**Header:** WHAT'S ALWAYS IN MY KITCHEN

Proteins: eggs · Greek yogurt · cottage cheese · firm tofu · canned tuna · white fish fillets (frozen) · salmon (frozen) · canned chickpeas and white beans.
Carbs: oats · rye crispbread · black or brown rice · wholemeal pasta · sweet potatoes · potatoes.
Vegetables and fruit: baby spinach · rocket · broccoli · mushrooms (canned and fresh) · cherry tomatoes · cucumber · peppers · frozen mixed vegetables · berries (frozen) · apples · lemons · avocado.
Flavour: olive oil · butter · soy sauce · garlic · onions · paprika · chili flakes · dried basil and oregano · cinnamon · vanilla essence · cocoa powder · maple syrup · peanut butter · tahini · chia seeds · protein powder (optional).

One shop, every recipe in this book.

---

## New page — BONUS: THE 5-MINUTE DESK STRETCH (last page before the conclusion)

**Header:** BEFORE YOU CLOSE THE BOOK: UNSTIFF IN 5 MINUTES

> Food is half of how I stay well while sitting for hours. The other half takes five minutes and no equipment. I made it into a free follow-along you can do at your desk, with the five moves I use between streams: neck, shoulders, wrists, hips, lower back.
>
> Get it here: [link to the free PDF / video]
>
> If you want the full version, a 30-day plan for people who sit all day, it's at [link, when the program exists].

---

## Page 2 — Contents (update after the changes)

I · Introduction · II · Measuring food with your hands · III · Low-calorie foods: swap, don't starve · IV · Intermittent fasting · V · Recipes (breakfasts · lunches and dinners · desserts) · VI · What's always in my kitchen · VII · Bonus: the 5-minute desk stretch · VIII · Conclusion

---

## Export settings (Canva)

Share → Download → PDF Standard (not PDF Print) → tick "Flatten PDF" and "Compress" if offered → target under 10 MB for the Kindle upload and under 15 MB for the Payhip edition. Before export: File → Settings → set the author to Kristine Maia so the PDF metadata no longer shows another name.
